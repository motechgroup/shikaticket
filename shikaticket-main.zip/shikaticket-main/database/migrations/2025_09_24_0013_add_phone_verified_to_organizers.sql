ALTER TABLE organizers
  ADD COLUMN phone_verified_at DATETIME NULL AFTER is_approved;


