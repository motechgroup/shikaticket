# ShikaTicket Documentation

Welcome to the ShikaTicket docs. Use the guides below to get started. No admin credentials are published here.

- Getting Started (All users)
- User Guide (Buyers)
- Organizer Guide
- Partners Guide
- Scanner Guide
- Email & SMS Templates
- Asset & Branding Guidelines
- Marketing & Communications

See the individual markdown files in this folder.
