# Partners Guide

## Partner Applications
- Public page `/partners` provides a form to register interest (name, email, phone, organization, category, message).
- Admin reviews and sets status (new/approved/rejected).

## Partner Logos on Homepage
- Admin-only: add partner logos (title, image, optional link, sort, active) in Admin > Partner Logos.
- Recommended image: transparent SVG/PNG, height ~40px, wide aspect, minimal padding.

## Sponsorships & Featured Banners
- Use Admin > Banners to upload campaign banners (recommended 1600×500). Provide outbound link.
