<div class="max-w-3xl mx-auto px-4 py-10">
	<a class="link" href="<?php echo base_url('/help'); ?>">← Back to Help</a>
	<div class="prose prose-invert max-w-none">
		<?php echo $html; ?>
	</div>
</div>
