<?php /** @var string $fullName */ ?>
<h1 style="margin:0 0 8px 0;color:#e5e7eb;font-size:20px">You're approved, <?php echo htmlspecialchars($fullName); ?>!</h1>
<p style="margin:0 0 12px 0;color:#d1d5db">You can now create and publish events on Ticko.</p>
<p style="margin:0;color:#d1d5db">Head over to your dashboard to get started.</p>


